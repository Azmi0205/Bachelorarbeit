/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define B1_Pin GPIO_PIN_13
#define B1_GPIO_Port GPIOC
#define VOLTAGE_W_Pin GPIO_PIN_0
#define VOLTAGE_W_GPIO_Port GPIOC
#define CURRENT_W_Pin GPIO_PIN_1
#define CURRENT_W_GPIO_Port GPIOC
#define PWM_LI_W_Pin GPIO_PIN_2
#define PWM_LI_W_GPIO_Port GPIOC
#define VOLTAGE_BUS_Pin GPIO_PIN_0
#define VOLTAGE_BUS_GPIO_Port GPIOA
#define VOLTAGE_U_Pin GPIO_PIN_1
#define VOLTAGE_U_GPIO_Port GPIOA
#define LPUART1_TX_Pin GPIO_PIN_2
#define LPUART1_TX_GPIO_Port GPIOA
#define LPUART1_RX_Pin GPIO_PIN_3
#define LPUART1_RX_GPIO_Port GPIOA
#define LD2_Pin GPIO_PIN_5
#define LD2_GPIO_Port GPIOA
#define CURRENT_U_Pin GPIO_PIN_6
#define CURRENT_U_GPIO_Port GPIOA
#define CURRENT_V_Pin GPIO_PIN_7
#define CURRENT_V_GPIO_Port GPIOA
#define ENC_CS_Pin GPIO_PIN_4
#define ENC_CS_GPIO_Port GPIOC
#define IMU_CS_Pin GPIO_PIN_5
#define IMU_CS_GPIO_Port GPIOC
#define PWM_LI_WB1_Pin GPIO_PIN_1
#define PWM_LI_WB1_GPIO_Port GPIOB
#define VOLTAGE_V_Pin GPIO_PIN_14
#define VOLTAGE_V_GPIO_Port GPIOB
#define PWM_HI_U_Pin GPIO_PIN_8
#define PWM_HI_U_GPIO_Port GPIOA
#define PWM_HI_V_Pin GPIO_PIN_9
#define PWM_HI_V_GPIO_Port GPIOA
#define PWM_LI_U_Pin GPIO_PIN_11
#define PWM_LI_U_GPIO_Port GPIOA
#define PWM_LI_V_Pin GPIO_PIN_12
#define PWM_LI_V_GPIO_Port GPIOA
#define T_SWDIO_Pin GPIO_PIN_13
#define T_SWDIO_GPIO_Port GPIOA
#define T_SWCLK_Pin GPIO_PIN_14
#define T_SWCLK_GPIO_Port GPIOA
#define T_SWO_Pin GPIO_PIN_3
#define T_SWO_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
